package com.atguigu.java8;

public interface MyFun {
	
	default String getName(){
		return "哈哈哈";
	}

}
