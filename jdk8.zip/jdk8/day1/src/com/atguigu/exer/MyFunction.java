package com.atguigu.exer;

@FunctionalInterface
public interface MyFunction {
	
	public String getValue(String str);

}
